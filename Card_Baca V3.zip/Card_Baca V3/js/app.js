const FILE_MANIFEST = "./manifest.json";
const LOCAL_KEY = "storyCards.local.v2";
const READING_KEY = "storyCards.reading.v2";
const THEME_KEY = "storyCards.theme.v2";
const CHUNK_TARGET = 1350;

const $ = (id) => document.getElementById(id);

const els = {
  sidebar: $("sidebar"),
  openSidebar: $("openSidebar"),
  closeSidebar: $("closeSidebar"),
  searchInput: $("searchInput"),
  fileStoryList: $("fileStoryList"),
  localStoryList: $("localStoryList"),
  fileCount: $("fileCount"),
  localCount: $("localCount"),
  activeTitle: $("activeTitle"),
  activeMeta: $("activeMeta"),
  sourceBadge: $("sourceBadge"),
  storyActions: $("storyActions"),
  readerArea: $("readerArea"),
  restartBtn: $("restartBtn"),
  editBtn: $("editBtn"),
  deleteBtn: $("deleteBtn"),
  newLocalStoryBtn: $("newLocalStoryBtn"),
  pickFolderBtn: $("pickFolderBtn"),
  folderInput: $("folderInput"),
  themeBtn: $("themeBtn"),
  storyDialog: $("storyDialog"),
  storyForm: $("storyForm"),
  dialogTitle: $("dialogTitle"),
  titleInput: $("titleInput"),
  contentInput: $("contentInput"),
  cancelBtn: $("cancelBtn"),
};

let fileStories = [];
let localStories = loadJSON(LOCAL_KEY, []);
let reading = loadJSON(READING_KEY, {});
let activeStory = null;
let editingLocalId = null;

function uid() {
  return crypto.randomUUID
    ? crypto.randomUUID()
    : Date.now().toString(36) + Math.random().toString(36).slice(2);
}

function loadJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function saveLocalStories() {
  localStorage.setItem(LOCAL_KEY, JSON.stringify(localStories));
}

function saveReading() {
  localStorage.setItem(READING_KEY, JSON.stringify(reading));
}

function bookmarkNotesKey(story, page) {
  return `${readingKey(story)}:${page}:note`;
}

function getBookmarkNote(story, page) {
  return localStorage.getItem(bookmarkNotesKey(story, page)) || "";
}

function saveBookmarkNote(story, page, note) {
  localStorage.setItem(bookmarkNotesKey(story, page), note);
}

function readingKey(story) {
  return `${story.source}:${story.id}`;
}

function getReadingState(story) {
  const key = readingKey(story);
  if (!reading[key]) reading[key] = { page: 0, bookmarks: [] };
  if (!Array.isArray(reading[key].bookmarks)) reading[key].bookmarks = [];
  return reading[key];
}

function escapeHtml(value = "") {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function renderInlineMarkdown(text) {
  let safe = escapeHtml(text);
  safe = safe.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
  safe = safe.replace(/__(.+?)__/g, "<strong>$1</strong>");
  safe = safe.replace(/(?<!\*)\*([^*\n]+?)\*(?!\*)/g, "<em>$1</em>");
  safe = safe.replace(/(?<!_)_([^_\n]+?)_(?!_)/g, "<em>$1</em>");
  return safe;
}

function renderMarkdown(text) {
  const lines = text.split(/\n/);
  const output = [];
  let paragraph = [];
  let quote = [];

  const flushParagraph = () => {
    if (!paragraph.length) return;
    output.push(`<p>${renderInlineMarkdown(paragraph.join("\n"))}</p>`);
    paragraph = [];
  };

  const flushQuote = () => {
    if (!quote.length) return;
    output.push(`<blockquote>${renderInlineMarkdown(quote.join("\n"))}</blockquote>`);
    quote = [];
  };

  for (const line of lines) {
    const trimmed = line.trim();

    if (/^---+$/.test(trimmed) || /^\*\*\*+$/.test(trimmed)) {
      flushParagraph();
      flushQuote();
      output.push("<hr>");
      continue;
    }

    const heading = line.match(/^(#{1,3})\s+(.+)$/);
    if (heading) {
      flushParagraph();
      flushQuote();
      const level = heading[1].length;
      output.push(`<h${level}>${renderInlineMarkdown(heading[2].trim())}</h${level}>`);
      continue;
    }

    if (/^>\s?/.test(line)) {
      flushParagraph();
      quote.push(line.replace(/^>\s?/, ""));
      continue;
    } else {
      flushQuote();
    }

    if (!trimmed) {
      flushParagraph();
      continue;
    }

    paragraph.push(line);
  }

  flushParagraph();
  flushQuote();
  return output.join("");
}

function splitMarkdownIntoCards(text, target = CHUNK_TARGET) {
  const cleaned = (text || "").trim();
  if (!cleaned) return [""];

  const paragraphs = cleaned.split(/\n\s*\n/).map(p => p.trim()).filter(Boolean);
  const cards = [];
  let current = "";

  for (const p of paragraphs) {
    const candidate = current ? current + "\n\n" + p : p;

    if (candidate.length <= target) {
      current = candidate;
      continue;
    }

    if (current) {
      cards.push(current);
      current = "";
    }

    if (p.length <= target) {
      current = p;
      continue;
    }

    const pieces = p.match(/[^.!?。！？\n]+[.!?。！？"”']*|\n+/g) || [p];
    let part = "";

    for (const piece of pieces) {
      if ((part + piece).length > target && part.trim()) {
        cards.push(part.trim());
        part = piece;
      } else {
        part += piece;
      }
    }

    if (part.trim()) current = part.trim();
  }

  if (current.trim()) cards.push(current.trim());
  return cards.length ? cards : [cleaned];
}

function splitHtmlIntoCards(html, target = CHUNK_TARGET) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  const nodes = Array.from(doc.body.children);
  if (!nodes.length) return [html];

  const cards = [];
  let current = "";
  let size = 0;

  for (const node of nodes) {
    const textSize = (node.textContent || "").trim().length;
    const serialized = node.outerHTML;

    if (size && size + textSize > target) {
      cards.push(current);
      current = "";
      size = 0;
    }

    current += serialized;
    size += textSize;

    if (textSize > target && current) {
      cards.push(current);
      current = "";
      size = 0;
    }
  }

  if (current) cards.push(current);
  return cards.length ? cards : [html];
}

function getCards(story) {
  return story.contentType === "html"
    ? splitHtmlIntoCards(story.content)
    : splitMarkdownIntoCards(story.content);
}

function renderCardContent(story, cardContent) {
  return story.contentType === "html"
    ? cardContent
    : renderMarkdown(cardContent);
}

async function loadFileLibrary() {
  try {
    const res = await fetch(FILE_MANIFEST, { cache: "no-store" });
    if (!res.ok) throw new Error(`manifest ${res.status}`);

    const manifest = await res.json();

    fileStories = await Promise.all(
      manifest.map(async item => {
        const response = await fetch(item.file, { cache: "no-store" });
        if (!response.ok) throw new Error(`${item.file}: ${response.status}`);
        const content = await response.text();

        return {
          id: item.id || item.file,
          title: item.title,
          file: item.file,
          sourceFile: item.sourceFile || item.file,
          source: "file",
          contentType: item.contentType || "markdown",
          content
        };
      })
    );
  } catch (error) {
    console.error("Gagal memuat file library:", error);
    fileStories = [];

    if (location.protocol === "file:") {
      console.warn("Story Cards dibuka melalui file://. Jalankan START_LOCAL.bat agar folder stories dapat dibaca.");
    }
  }
}


async function importFolderFiles(fileList) {
  const supported = Array.from(fileList)
    .filter(file => /\.(md|txt)$/i.test(file.name))
    .sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));

  const skippedDocx = Array.from(fileList).filter(file => /\.docx$/i.test(file.name)).length;

  const imported = [];

  for (const file of supported) {
    const content = await file.text();
    const titleMatch = content.match(/^#\s+(.+)$/m);
    const fallbackTitle = file.name
      .replace(/\.[^.]+$/, "")
      .replace(/^\d+[-_. ]*/, "")
      .replace(/[-_]+/g, " ");

    imported.push({
      id: `localfolder:${file.webkitRelativePath || file.name}`,
      title: titleMatch ? titleMatch[1].trim() : fallbackTitle,
      file: file.webkitRelativePath || file.name,
      sourceFile: file.webkitRelativePath || file.name,
      source: "file",
      contentType: "markdown",
      content
    });
  }

  fileStories = imported;

  if (fileStories.length) {
    activeStory = fileStories[0];
  }

  render();

  if (skippedDocx) {
    alert(
      `${skippedDocx} file DOCX tidak dibuka lewat mode file://. ` +
      `Untuk preview DOCX, gunakan START_LOCAL.bat atau deploy ke Netlify.`
    );
  }
}

function allStories() {
  return [
    ...fileStories,
    ...localStories.map(s => ({ ...s, source: "local", contentType: "markdown" }))
  ];
}

function findStory(source, id) {
  const list = source === "file" ? fileStories : localStories;
  const found = list.find(s => s.id === id);
  if (!found) return null;
  return source === "file"
    ? found
    : { ...found, source: "local", contentType: "markdown" };
}

function formatSource(story) {
  if (story.source === "file") {
    const ext = (story.sourceFile || story.file || "").split(".").pop()?.toUpperCase();
    return `FILE ${ext || ""}`.trim();
  }
  return "LOCAL";
}

function activateStory(story) {
  activeStory = story;
  saveReading();
  render();
  els.sidebar.classList.remove("open");
}

function renderStoryLists() {
  const query = els.searchInput.value.trim().toLowerCase();

  const filteredFiles = fileStories.filter(s => s.title.toLowerCase().includes(query));
  const filteredLocals = localStories.filter(s => s.title.toLowerCase().includes(query));

  els.fileCount.textContent = fileStories.length;
  els.localCount.textContent = localStories.length;

  renderList(els.fileStoryList, filteredFiles, "file");
  renderList(els.localStoryList, filteredLocals, "local");
}

function renderList(container, stories, source) {
  container.innerHTML = "";

  if (!stories.length) {
    container.innerHTML = `<div class="muted" style="padding:8px 3px">${source === "file" ? "Tidak ada file." : "Belum ada cerita lokal."}</div>`;
    return;
  }

  for (const story of stories) {
    const normalized = source === "file"
      ? story
      : { ...story, source: "local", contentType: "markdown" };

    const state = getReadingState(normalized);
    const pages = getCards(normalized).length;

    const btn = document.createElement("button");
    btn.className = "story-item";
    if (activeStory && activeStory.source === source && activeStory.id === story.id) {
      btn.classList.add("active");
    }

    btn.innerHTML = `
      <div class="story-item-title"></div>
      <div class="story-item-meta">${pages} card · terakhir ${Math.min((state.page || 0) + 1, pages)}/${pages}</div>
    `;
    btn.querySelector(".story-item-title").textContent = story.title;
    btn.addEventListener("click", () => activateStory(normalized));

    container.appendChild(btn);
  }
}

function normalizeReading(story, cardCount) {
  const state = getReadingState(story);
  state.page = Math.min(Math.max(Number(state.page) || 0, 0), Math.max(cardCount - 1, 0));
  state.bookmarks = [...new Set(
    state.bookmarks
      .map(Number)
      .filter(n => Number.isInteger(n) && n >= 0 && n < cardCount)
  )].sort((a, b) => a - b);
  return state;
}

function toggleBookmark(page) {
  if (!activeStory) return;
  const cards = getCards(activeStory);
  const state = normalizeReading(activeStory, cards.length);
  const index = state.bookmarks.indexOf(page);

  if (index >= 0) state.bookmarks.splice(index, 1);
  else state.bookmarks.push(page);

  state.bookmarks.sort((a, b) => a - b);
  saveReading();
  renderReader();
}

function jumpToPage(page) {
  if (!activeStory) return;
  const cards = getCards(activeStory);
  const state = normalizeReading(activeStory, cards.length);
  state.page = Math.min(Math.max(page, 0), cards.length - 1);
  saveReading();
  renderReader();
  renderStoryLists();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function changePage(delta) {
  if (!activeStory) return;
  const state = getReadingState(activeStory);
  jumpToPage((state.page || 0) + delta);
}

function renderReader() {
  if (!activeStory) {
    els.activeTitle.textContent = "Pilih cerita";
    const openedAsFile = location.protocol === "file:";
    els.activeMeta.textContent = openedAsFile
      ? "Library belum dibuat. Tutup halaman lalu double-click START_LOCAL.bat."
      : "Cerita dari folder stories akan muncul otomatis setelah deploy.";
    els.sourceBadge.textContent = openedAsFile ? "LOCAL FILE MODE" : "READY";
    els.storyActions.hidden = true;
    els.readerArea.innerHTML = `
      <div class="empty-state">
        <div>
          <div style="font-size:40px;margin-bottom:10px">⌁</div>
          <strong style="color:var(--text)">Belum ada cerita aktif.</strong>
          <div style="margin-top:7px">${
            location.protocol === "file:"
              ? "Double-click START_LOCAL.bat dari folder utama agar file stories dimuat otomatis."
              : "Pilih file dari sidebar atau buat cerita lokal."
          }</div>
        </div>
      </div>
    `;
    return;
  }

  const cards = getCards(activeStory);
  const state = normalizeReading(activeStory, cards.length);
  const page = state.page;
  const bookmarked = state.bookmarks.includes(page);
  const progress = ((page + 1) / cards.length) * 100;

  els.activeTitle.textContent = activeStory.title;
  els.activeMeta.textContent = activeStory.source === "file"
    ? `${activeStory.sourceFile || activeStory.file} · ${cards.length} card`
    : `${cards.length} card · tersimpan hanya di browser ini`;
  els.sourceBadge.textContent = formatSource(activeStory);
  els.storyActions.hidden = false;

  document.querySelectorAll(".local-action").forEach(el => {
    el.hidden = activeStory.source !== "local";
  });

  els.readerArea.innerHTML = `
    <article class="reader">
      <div class="reader-head">
        <div class="chapter-label">Reading card</div>

        <div class="reader-tools">
          <button
            id="bookmarkBtn"
            class="bookmark-btn ${bookmarked ? "active" : ""}"
            type="button"
            aria-pressed="${bookmarked}"
            title="${bookmarked ? "Hapus bookmark" : "Bookmark card ini"}"
          >
            ${bookmarked ? "★ Bookmarked" : "☆ Bookmark"}
          </button>
          <div class="counter-pill">${page + 1} / ${cards.length}</div>
        </div>
      </div>

      <div id="readerCard" class="reader-card" tabindex="0">
        <div class="story-text" id="storyText"></div>
        <div class="reader-hint">${page < cards.length - 1 ? "Klik card untuk lanjut →" : "Selesai dibaca"}</div>
      </div>

      <div class="reader-foot">
        <button id="prevBtn" class="ghost-btn nav-btn" ${page === 0 ? "disabled" : ""}>← Sebelumnya</button>
        <div class="progress-track"><div class="progress-bar" style="width:${progress}%"></div></div>
        <button id="nextBtn" class="primary-btn nav-btn" ${page === cards.length - 1 ? "disabled" : ""}>Berikutnya →</button>
      </div>
    </article>

    <section class="bookmark-panel">
      <div class="bookmark-panel-head">
        <div class="bookmark-panel-title">★ Bookmark card</div>
        <div class="muted">${state.bookmarks.length} tersimpan</div>
      </div>

      ${
        state.bookmarks.length
          ? `<div class="bookmark-list">
              ${state.bookmarks.map(i => `
                <div class="bookmark-card ${i === page ? "current" : ""}">
                  <button class="bookmark-jump" data-jump="${i}">
                    <div class="bookmark-card-title">Card ${i + 1}</div>
                    <div class="bookmark-preview">${escapeHtml(getCards(activeStory)[i].slice(0,120))}...</div>
                  </button>
                  <textarea class="bookmark-note" data-note="${i}" placeholder="Tambahkan catatan...">${escapeHtml(getBookmarkNote(activeStory,i))}</textarea>
                  <div class="bookmark-card-actions">
                    <button class="save-note" data-save-note="${i}">Simpan</button>
                    <button class="remove-bookmark" data-remove="${i}">Hapus</button>
                  </div>
                </div>
              `).join("")}
             </div>`
          : `<div class="bookmark-empty">Belum ada card yang dibookmark.</div>`
      }
    </section>
  `;

  $("storyText").innerHTML = renderCardContent(activeStory, cards[page]);

  $("prevBtn").addEventListener("click", () => changePage(-1));
  $("nextBtn").addEventListener("click", () => changePage(1));
  $("bookmarkBtn").addEventListener("click", e => {
    e.stopPropagation();
    toggleBookmark(page);
  });

  document.querySelectorAll("[data-save-note]").forEach(btn => {
    btn.addEventListener("click", () => {
      const index = Number(btn.dataset.saveNote);
      const area = document.querySelector(`[data-note="${index}"]`);
      saveBookmarkNote(activeStory, index, area.value);
      btn.textContent = "Tersimpan ✓";
      setTimeout(() => btn.textContent = "Simpan", 1200);
    });
  });

  document.querySelectorAll("[data-remove]").forEach(btn => {
    btn.addEventListener("click", () => {
      const index = Number(btn.dataset.remove);
      const state = getReadingState(activeStory);
      state.bookmarks = state.bookmarks.filter(x => x !== index);
      saveReading();
      renderReader();
    });
  });

  $("readerCard").addEventListener("click", () => {
    if (window.getSelection().toString()) return;
    if (page < cards.length - 1) changePage(1);
  });

  $("readerCard").addEventListener("keydown", e => {
    if ((e.key === "Enter" || e.key === " ") && page < cards.length - 1) {
      e.preventDefault();
      changePage(1);
    }
  });

  document.querySelectorAll("[data-jump]").forEach(btn => {
    btn.addEventListener("click", () => jumpToPage(Number(btn.dataset.jump)));
  });
}

function render() {
  renderStoryLists();
  renderReader();
}

function openLocalEditor(story = null) {
  editingLocalId = story?.id || null;
  els.dialogTitle.textContent = story ? "Edit cerita lokal" : "Cerita lokal baru";
  els.titleInput.value = story?.title || "";
  els.contentInput.value = story?.content || "";
  els.storyDialog.showModal();
  setTimeout(() => els.titleInput.focus(), 30);
}

function deleteActiveLocal() {
  if (!activeStory || activeStory.source !== "local") return;
  if (!confirm(`Hapus "${activeStory.title}"?`)) return;

  localStories = localStories.filter(s => s.id !== activeStory.id);
  delete reading[readingKey(activeStory)];
  activeStory = null;

  saveLocalStories();
  saveReading();
  render();
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  localStorage.setItem(THEME_KEY, theme);
  els.themeBtn.textContent = theme === "dark" ? "☀ Light mode" : "☾ Dark mode";
}

els.searchInput.addEventListener("input", renderStoryLists);

els.pickFolderBtn.addEventListener("click", () => els.folderInput.click());

els.folderInput.addEventListener("change", async () => {
  if (!els.folderInput.files?.length) return;
  await importFolderFiles(els.folderInput.files);
});

els.newLocalStoryBtn.addEventListener("click", () => openLocalEditor());

els.editBtn.addEventListener("click", () => {
  if (!activeStory || activeStory.source !== "local") return;
  const source = localStories.find(s => s.id === activeStory.id);
  if (source) openLocalEditor(source);
});

els.deleteBtn.addEventListener("click", deleteActiveLocal);

els.restartBtn.addEventListener("click", () => jumpToPage(0));

els.cancelBtn.addEventListener("click", () => els.storyDialog.close());

els.storyForm.addEventListener("submit", e => {
  e.preventDefault();

  const title = els.titleInput.value.trim();
  const content = els.contentInput.value.trim();
  if (!title || !content) return;

  if (editingLocalId) {
    const story = localStories.find(s => s.id === editingLocalId);
    if (story) {
      story.title = title;
      story.content = content;
      story.updatedAt = Date.now();
      activeStory = { ...story, source: "local", contentType: "markdown" };
    }
  } else {
    const story = {
      id: uid(),
      title,
      content,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    localStories.unshift(story);
    activeStory = { ...story, source: "local", contentType: "markdown" };
  }

  saveLocalStories();
  els.storyDialog.close();
  render();
});

els.themeBtn.addEventListener("click", () => {
  const current = document.documentElement.dataset.theme || "light";
  applyTheme(current === "dark" ? "light" : "dark");
});

els.openSidebar.addEventListener("click", () => els.sidebar.classList.add("open"));
els.closeSidebar.addEventListener("click", () => els.sidebar.classList.remove("open"));

document.addEventListener("keydown", e => {
  if (els.storyDialog.open) return;
  if (e.key === "ArrowRight") changePage(1);
  if (e.key === "ArrowLeft") changePage(-1);
});

async function init() {
  const savedTheme = localStorage.getItem(THEME_KEY);
  const preferred = matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  applyTheme(savedTheme || preferred);

  const fileMode = location.protocol === "file:";
  els.pickFolderBtn.hidden = true;

  if (fileMode) {
    fileStories = Array.isArray(window.LOCAL_FILE_STORIES)
      ? window.LOCAL_FILE_STORIES
      : [];
  } else {
    await loadFileLibrary();
  }

  const previous = Object.keys(reading)
    .map(key => {
      const [source, ...idParts] = key.split(":");
      return findStory(source, idParts.join(":"));
    })
    .find(Boolean);

  activeStory = previous || fileStories[0] || (
    localStories[0]
      ? { ...localStories[0], source: "local", contentType: "markdown" }
      : null
  );

  render();
}

init();
