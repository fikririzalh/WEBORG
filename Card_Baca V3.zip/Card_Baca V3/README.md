# Story Cards - Manual Netlify Upload

Tidak perlu GitHub.

Masukkan `.md`, `.txt`, atau `.docx` ke `public/stories/`, lalu drag seluruh folder project ke Netlify melalui **Deploy manually** saat sudah login.

Baca `UPLOAD_KE_NETLIFY.txt`.
