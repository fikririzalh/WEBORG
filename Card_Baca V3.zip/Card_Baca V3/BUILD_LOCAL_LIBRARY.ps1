﻿$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$StoriesDir = Join-Path $Root "public\stories"
$GeneratedDir = Join-Path $Root "public\generated"
$OutputFile = Join-Path $GeneratedDir "local-stories.js"

New-Item -ItemType Directory -Force -Path $StoriesDir | Out-Null
New-Item -ItemType Directory -Force -Path $GeneratedDir | Out-Null

function Get-TitleFromContent {
    param(
        [string]$Content,
        [string]$Fallback
    )

    $match = [regex]::Match($Content, '(?m)^#\s+(.+)$')
    if ($match.Success) {
        return $match.Groups[1].Value.Trim()
    }

    return $Fallback
}

function Get-FallbackTitle {
    param([string]$FileName)

    $name = [System.IO.Path]::GetFileNameWithoutExtension($FileName)
    $name = [regex]::Replace($name, '^\d+[-_. ]*', '')
    $name = $name -replace '[-_]+', ' '
    if ([string]::IsNullOrWhiteSpace($name)) {
        return [System.IO.Path]::GetFileNameWithoutExtension($FileName)
    }
    return $name.Trim()
}

$files = Get-ChildItem -Path $StoriesDir -File |
    Where-Object { $_.Extension -match '^\.(md|txt)$' } |
    Sort-Object Name

$stories = @()

foreach ($file in $files) {
    try {
        $content = [System.IO.File]::ReadAllText(
            $file.FullName,
            [System.Text.Encoding]::UTF8
        )
    }
    catch {
        # Fallback untuk file TXT Windows/ANSI
        $content = Get-Content -Raw -LiteralPath $file.FullName
    }

    $fallback = Get-FallbackTitle $file.Name
    $title = Get-TitleFromContent -Content $content -Fallback $fallback

    $stories += [PSCustomObject]@{
        id = "file:$($file.Name)"
        title = $title
        source = "file"
        sourceFile = "stories/$($file.Name)"
        file = "stories/$($file.Name)"
        contentType = "markdown"
        content = $content
    }
}

# ConvertTo-Json safely escapes strings, newlines, quotes, etc.
$json = $stories | ConvertTo-Json -Depth 6 -Compress

# Important: when only one object exists, force JSON array
if ($stories.Count -eq 0) {
    $json = "[]"
}
elseif ($stories.Count -eq 1) {
    $json = "[" + ($stories[0] | ConvertTo-Json -Depth 6 -Compress) + "]"
}

$js = "window.LOCAL_FILE_STORIES = $json;"
[System.IO.File]::WriteAllText(
    $OutputFile,
    $js,
    (New-Object System.Text.UTF8Encoding($false))
)

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " STORY CARDS - LOCAL LIBRARY GENERATED" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Ditemukan $($stories.Count) file .txt/.md:" -ForegroundColor Green

foreach ($story in $stories) {
    Write-Host " - $($story.title)" -ForegroundColor White
}

if ($stories.Count -eq 0) {
    Write-Host ""
    Write-Host "Tidak ada file .txt/.md di public\stories" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Membuka Story Cards..." -ForegroundColor Green

$IndexFile = Join-Path $Root "public\index.html"
Start-Process $IndexFile
