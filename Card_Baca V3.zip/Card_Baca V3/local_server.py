from pathlib import Path
from urllib.parse import quote
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import webbrowser
import threading
import json
import re
import html
import zipfile
import xml.etree.ElementTree as ET
import socket
import os

ROOT = Path(__file__).resolve().parent
PUBLIC = ROOT / "public"
STORIES = PUBLIC / "stories"
GENERATED = PUBLIC / "generated"
MANIFEST = PUBLIC / "manifest.json"

STORIES.mkdir(parents=True, exist_ok=True)
GENERATED.mkdir(parents=True, exist_ok=True)

def natural_key(value):
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r"(\d+)", value)]

def fallback_title(filename):
    name = Path(filename).stem
    name = re.sub(r"^\d+[-_. ]*", "", name)
    name = re.sub(r"[-_]+", " ", name).strip()
    return name or Path(filename).stem

def markdown_title(content, fallback):
    match = re.search(r"^#\s+(.+)$", content, re.MULTILINE)
    return match.group(1).strip() if match else fallback

def docx_to_html(docx_path):
    """Basic DOCX parser using Python standard library only."""
    NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    with zipfile.ZipFile(docx_path) as z:
        xml_bytes = z.read("word/document.xml")

    root = ET.fromstring(xml_bytes)
    output = []
    first_text = None

    for p in root.findall(".//w:body/w:p", NS):
        p_style = p.find("./w:pPr/w:pStyle", NS)
        style = ""
        if p_style is not None:
            style = p_style.attrib.get(f"{{{NS['w']}}}val", "").lower()

        chunks = []
        plain = []

        for run in p.findall("./w:r", NS):
            text_parts = [t.text or "" for t in run.findall(".//w:t", NS)]
            if not text_parts:
                continue

            text_value = "".join(text_parts)
            plain.append(text_value)

            rpr = run.find("./w:rPr", NS)
            bold = rpr is not None and rpr.find("./w:b", NS) is not None
            italic = rpr is not None and rpr.find("./w:i", NS) is not None

            safe = html.escape(text_value)
            if bold:
                safe = f"<strong>{safe}</strong>"
            if italic:
                safe = f"<em>{safe}</em>"
            chunks.append(safe)

        paragraph_text = "".join(plain).strip()
        if paragraph_text and first_text is None:
            first_text = paragraph_text

        if not chunks:
            continue

        body = "".join(chunks)

        if "title" in style or style in ("heading1", "heading 1"):
            tag = "h1"
        elif style in ("heading2", "heading 2"):
            tag = "h2"
        elif style in ("heading3", "heading 3"):
            tag = "h3"
        else:
            tag = "p"

        output.append(f"<{tag}>{body}</{tag}>")

    return "\n".join(output), first_text

def slugify(name):
    slug = re.sub(r"[^\w.-]+", "-", name, flags=re.UNICODE)
    slug = re.sub(r"-+", "-", slug).strip("-").lower()
    return slug or "story"

def generate_manifest():
    entries = []

    files = sorted(
        [p for p in STORIES.iterdir() if p.is_file() and p.suffix.lower() in {".md", ".txt", ".docx"}],
        key=lambda p: natural_key(p.name)
    )

    for file_path in files:
        ext = file_path.suffix.lower()
        fallback = fallback_title(file_path.name)

        if ext in {".md", ".txt"}:
            content = file_path.read_text(encoding="utf-8-sig", errors="replace")
            entries.append({
                "id": f"file:{file_path.name}",
                "title": markdown_title(content, fallback),
                "file": f"stories/{quote(file_path.name)}",
                "sourceFile": f"stories/{file_path.name}",
                "contentType": "markdown"
            })
            continue

        if ext == ".docx":
            try:
                converted, first_text = docx_to_html(file_path)
                generated_name = slugify(file_path.stem) + ".html"
                (GENERATED / generated_name).write_text(converted, encoding="utf-8")

                title = first_text if first_text and len(first_text) <= 140 else fallback
                entries.append({
                    "id": f"file:{file_path.name}",
                    "title": title,
                    "file": f"generated/{quote(generated_name)}",
                    "sourceFile": f"stories/{file_path.name}",
                    "contentType": "html"
                })
            except Exception as exc:
                print(f"[WARN] DOCX gagal diproses: {file_path.name}: {exc}")

    MANIFEST.write_text(json.dumps(entries, ensure_ascii=False, indent=2), encoding="utf-8")

    print()
    print("=" * 62)
    print(f"Story Cards: ditemukan {len(entries)} cerita.")
    for item in entries:
        print(f"  - {item['title']}  [{item['sourceFile']}]")
    print("=" * 62)

def free_port(start=8765, end=8799):
    for port in range(start, end + 1):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                pass
    raise RuntimeError("Tidak menemukan port lokal yang kosong.")

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(PUBLIC), **kwargs)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

if __name__ == "__main__":
    generate_manifest()
    port = free_port()
    url = f"http://127.0.0.1:{port}/"

    print(f"\nMembuka: {url}")
    print("Jangan tutup jendela ini selama Story Cards sedang digunakan.")
    print("Tekan Ctrl+C untuk menghentikan server.\n")

    threading.Timer(0.7, lambda: webbrowser.open(url)).start()

    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStory Cards dihentikan.")
    finally:
        server.server_close()
