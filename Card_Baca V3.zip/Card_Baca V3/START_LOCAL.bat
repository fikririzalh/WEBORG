@echo off
setlocal
cd /d "%~dp0"
title Story Cards

echo.
echo ============================================================
echo   STORY CARDS
echo ============================================================
echo.
echo Membaca file dari public\stories ...
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_LOCAL_LIBRARY.ps1"

if errorlevel 1 (
    echo.
    echo [ERROR] Gagal membuat library lokal.
    echo.
    pause
)

endlocal
