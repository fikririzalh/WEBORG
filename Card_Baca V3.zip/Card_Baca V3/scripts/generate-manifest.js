const fs = require("fs");
const path = require("path");
const mammoth = require("mammoth");

const ROOT = path.join(__dirname, "..");
const STORIES_DIR = path.join(ROOT, "public", "stories");
const GENERATED_DIR = path.join(ROOT, "public", "generated");
const MANIFEST_FILE = path.join(ROOT, "public", "manifest.json");

fs.mkdirSync(STORIES_DIR, { recursive: true });
fs.mkdirSync(GENERATED_DIR, { recursive: true });

function slugify(name) {
  return name
    .normalize("NFKD")
    .replace(/[^\w.-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .toLowerCase();
}

function filenameTitle(file) {
  return path
    .parse(file)
    .name
    .replace(/^\d+[-_. ]*/, "")
    .replace(/[-_]+/g, " ")
    .replace(/\b\w/g, c => c.toUpperCase());
}

function titleFromMarkdown(content, fallback) {
  const match = content.match(/^#\s+(.+)$/m);
  return match ? match[1].trim() : fallback;
}

async function buildManifest() {
  const files = fs
    .readdirSync(STORIES_DIR)
    .filter(file => /\.(md|txt|docx)$/i.test(file))
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));

  const manifest = [];

  for (const file of files) {
    const ext = path.extname(file).toLowerCase();
    const sourcePath = path.join(STORIES_DIR, file);
    const fallbackTitle = filenameTitle(file);

    if (ext === ".md" || ext === ".txt") {
      const content = fs.readFileSync(sourcePath, "utf8");

      manifest.push({
        id: `file:${file}`,
        title: titleFromMarkdown(content, fallbackTitle),
        file: `stories/${encodeURIComponent(file)}`,
        sourceFile: `stories/${file}`,
        contentType: "markdown"
      });

      continue;
    }

    if (ext === ".docx") {
      const htmlResult = await mammoth.convertToHtml(
        { path: sourcePath },
        {
          styleMap: [
            "p[style-name='Title'] => h1:fresh",
            "p[style-name='Heading 1'] => h1:fresh",
            "p[style-name='Heading 2'] => h2:fresh",
            "p[style-name='Heading 3'] => h3:fresh"
          ]
        }
      );

      const rawResult = await mammoth.extractRawText({ path: sourcePath });
      const firstLine = rawResult.value
        .split(/\r?\n/)
        .map(s => s.trim())
        .find(Boolean);

      const generatedName = `${slugify(path.parse(file).name)}.html`;
      const generatedPath = path.join(GENERATED_DIR, generatedName);

      fs.writeFileSync(generatedPath, htmlResult.value, "utf8");

      manifest.push({
        id: `file:${file}`,
        title: firstLine && firstLine.length <= 140 ? firstLine : fallbackTitle,
        file: `generated/${encodeURIComponent(generatedName)}`,
        sourceFile: `stories/${file}`,
        contentType: "html"
      });

      if (htmlResult.messages.length) {
        console.warn(`Warnings for ${file}:`);
        htmlResult.messages.forEach(message => console.warn(`- ${message.message}`));
      }
    }
  }

  fs.writeFileSync(MANIFEST_FILE, JSON.stringify(manifest, null, 2), "utf8");

  console.log(`Story manifest generated: ${manifest.length} file(s).`);
  manifest.forEach(item => {
    console.log(`- ${item.title} <- ${item.sourceFile}`);
  });
}

buildManifest().catch(error => {
  console.error(error);
  process.exit(1);
});
